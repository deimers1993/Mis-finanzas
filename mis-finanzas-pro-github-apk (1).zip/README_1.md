# Mis Finanzas Pro - APK via GitHub Actions

Proyecto listo para compilar APK en la nube sin Android Studio.

## Pasos

### 1. Crear repo en GitHub
- Crea repo vacio: mis-finanzas-pro
- Sube este codigo

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/mis-finanzas-pro.git
git push -u origin main
```

### 2. Compilacion automatica
- Ve a pestaña Actions
- Veras workflow Build APK corriendo
- Espera 4-5 min

### 3. Descargar APK
- Entra al workflow que termino en verde
- Abajo en Artifacts descarga mis-finanzas-pro-debug.zip
- Dentro esta app-debug.apk instalable

### 4. APK Firmado para Play Store (opcional)
Genera keystore una vez local:
```
keytool -genkey -v -keystore release.keystore -alias misfinanzas -keyalg RSA -keysize 2048 -validity 10000
base64 -i release.keystore | pbcopy
```
En GitHub: Settings > Secrets > Actions > New secret:
- KEYSTORE_BASE64
- KEYSTORE_PASSWORD
- KEY_ALIAS = misfinanzas
- KEY_PASSWORD

Luego corre manualmente Build Release APK
