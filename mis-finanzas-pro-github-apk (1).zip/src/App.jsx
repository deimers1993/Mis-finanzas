import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Home, Receipt, Target, Briefcase,
  Settings, Eye, EyeOff, Sun, Moon, Plus, X, Search,
  ShoppingCart, Bus, Headphones, Pill, Package,
  Trash2, TrendingUp, TrendingDown, DollarSign, Calendar, LogOut,
  PieChart as PieChartIcon, Check, Bot, Wallet, ArrowUpRight, ArrowDownRight,
  Sparkles, Lightbulb, Download, AlertTriangle
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';

// --- CONFIG ---
const CATEGORIES: Record<string, { label: string, color: string, bg: string, dot: string, icon: any }> = {
  comida: { label: 'Comida', color: 'text-emerald-600', bg: 'bg-emerald-100 dark:bg-emerald-900/30', dot: 'bg-emerald-500', icon: ShoppingCart },
  transporte: { label: 'Transporte', color: 'text-sky-600', bg: 'bg-sky-100 dark:bg-sky-900/30', dot: 'bg-sky-500', icon: Bus },
  ocio: { label: 'Ocio', color: 'text-violet-600', bg: 'bg-violet-100 dark:bg-violet-900/30', dot: 'bg-violet-500', icon: Headphones },
  salud: { label: 'Salud', color: 'text-rose-600', bg: 'bg-rose-100 dark:bg-rose-900/30', dot: 'bg-rose-500', icon: Pill },
  otros: { label: 'Otros', color: 'text-zinc-600', bg: 'bg-zinc-200 dark:bg-zinc-800', dot: 'bg-zinc-400', icon: Package },
};

const PAYMENT_METHODS = ['Nequi', 'Daviplata', 'Efectivo', 'Tarjeta', 'Bancolombia'];
const CAT_KEYS = Object.keys(CATEGORIES);

const APP_COLORS: Record<string, { name: string, bg: string, text: string, activeNav: string, preview: string, ring: string, hex: string }> = {
  zinc: { name: 'Clásico', bg: 'bg-zinc-900 dark:bg-white', text: 'text-white dark:text-zinc-900', activeNav: 'bg-zinc-800 dark:bg-zinc-200 text-white dark:text-black', preview: 'bg-zinc-900 dark:bg-white', ring: 'ring-zinc-900', hex: '#18181b' },
  emerald: { name: 'Esmeralda', bg: 'bg-emerald-500', text: 'text-white', activeNav: 'bg-emerald-500 text-white', preview: 'bg-emerald-500', ring: 'ring-emerald-500', hex: '#10b981' },
  violet: { name: 'Violeta', bg: 'bg-violet-500', text: 'text-white', activeNav: 'bg-violet-500 text-white', preview: 'bg-violet-500', ring: 'ring-violet-500', hex: '#8b5cf6' },
  sky: { name: 'Cielo', bg: 'bg-sky-500', text: 'text-white', activeNav: 'bg-sky-500 text-white', preview: 'bg-sky-500', ring: 'ring-sky-500', hex: '#0ea5e9' },
  rose: { name: 'Rosa', bg: 'bg-rose-500', text: 'text-white', activeNav: 'bg-rose-500 text-white', preview: 'bg-rose-500', ring: 'ring-rose-500', hex: '#f43f5e' },
  amber: { name: 'Ámbar', bg: 'bg-amber-500', text: 'text-white', activeNav: 'bg-amber-500 text-white', preview: 'bg-amber-500', ring: 'ring-amber-500', hex: '#f59e0b' }
};

const formatCurrency = (amount: number) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(amount || 0);
const formatShortCurrency = (amount: number) => {
  if (Math.abs(amount) >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
  if (Math.abs(amount) >= 1000) return `$${(amount / 1000).toFixed(0)}k`;
  return formatCurrency(amount);
};

// SAFE DATE PARSER - avoids timezone bug
function parseDateStr(dateStr: string) {
  if (!dateStr) return { y: 0, m: 0, d: 0 };
  const parts = dateStr.split('-').map(Number);
  return { y: parts[0], m: parts[1], d: parts[2] };
}
function isSameMonth(dateStr: string, month: number, year: number) {
  const { y, m } = parseDateStr(dateStr);
  return y === year && m === month + 1;
}
function toISODate(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function useLocalStorage<T>(key: string, initialValue: T): [T, (v: T | ((p: T) => T)) => void] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch { return initialValue; }
  });
  const setValue = (value: any) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch {}
  };
  return [storedValue, setValue];
}

// --- APP ---
export default function App() {
  const [user, setUser] = useLocalStorage<any>('misfinanzas_user', null);
  const [theme, setTheme] = useLocalStorage('misfinanzas_theme', 'light');
  const [appColor, setAppColor] = useLocalStorage('misfinanzas_color', 'zinc');
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2800);
  };

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  const colorTheme = (APP_COLORS as any)[appColor] || APP_COLORS.zinc;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        *{font-family:'Inter',sans-serif}
        @keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        @keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
        .no-scrollbar::-webkit-scrollbar{display:none}
        .no-scrollbar{-ms-overflow-style:none;scrollbar-width:none}
      `}</style>

      {!user ? (
        <LoginScreen onLogin={setUser} colorTheme={colorTheme} showToast={showToast} />
      ) : (
        <MainApp
          user={user}
          onLogout={() => setUser(null)}
          theme={theme}
          toggleTheme={() => setTheme(theme === 'light' ? 'dark' : 'light')}
          appColor={appColor}
          setAppColor={setAppColor}
          colorTheme={colorTheme}
          showToast={showToast}
        />
      )}

      {toast && (
        <div className="fixed bottom-[96px] left-1/2 -translate-x-1/2 z-[100] bg-zinc-900 dark:bg-white text-white dark:text-black px-5 py-3 rounded-full text-sm font-medium shadow-2xl animate-[fadeIn_0.2s_ease] max-w-[90vw] text-center">
          {toast}
        </div>
      )}
    </>
  );
}

function LoginScreen({ onLogin, colorTheme, showToast }: any) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isRegister, setIsRegister] = useState(false);

  const handleAuth = () => {
    if (!username.trim()) { showToast("Ingresa un usuario válido"); return; }
    onLogin({ username: username.trim(), isGuest: false });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-50 dark:bg-zinc-950 p-4">
      <div className="w-full max-w-sm bg-white dark:bg-zinc-900 rounded-[32px] p-8 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.15)] border border-zinc-100 dark:border-zinc-800">
        <div className="flex flex-col items-center mb-8">
          <div className={`w-16 h-16 rounded-[18px] flex items-center justify-center text-[22px] font-extrabold mb-4 shadow-lg ${colorTheme.bg} ${colorTheme.text}`}>M$</div>
          <h1 className="text-[26px] font-extrabold tracking-tight text-zinc-900 dark:text-white">Mis Finanzas Pro</h1>
          <p className="text-zinc-500 text-[13px] mt-1 font-medium">Tu dinero bajo control • Colombia</p>
          <div className="mt-3 flex gap-1.5">
            <span className="h-1.5 w-6 rounded-full bg-zinc-900 dark:bg-white"></span>
            <span className="h-1.5 w-1.5 rounded-full bg-zinc-300"></span>
            <span className="h-1.5 w-1.5 rounded-full bg-zinc-200"></span>
          </div>
        </div>
        <div className="space-y-3">
          <input type="text" placeholder="Usuario" value={username} onChange={e => setUsername(e.target.value)} className="w-full h-[52px] px-4 rounded-2xl bg-zinc-100 dark:bg-zinc-800 border border-transparent focus:border-zinc-900 dark:focus:border-white outline-none text-[15px] font-medium dark:text-white transition" />
          <input type="password" placeholder="Contraseña" value={password} onChange={e => setPassword(e.target.value)} className="w-full h-[52px] px-4 rounded-2xl bg-zinc-100 dark:bg-zinc-800 border border-transparent focus:border-zinc-900 dark:focus:border-white outline-none text-[15px] font-medium dark:text-white transition" />
          <button onClick={handleAuth} className={`w-full h-[52px] rounded-2xl font-bold text-[15px] transition-transform active:scale-[0.98] ${colorTheme.bg} ${colorTheme.text} shadow-lg`}>
            {isRegister ? 'Crear cuenta' : 'Entrar'}
          </button>
          <button onClick={() => setIsRegister(!isRegister)} className="w-full text-[13px] text-zinc-500 font-semibold py-2 hover:text-zinc-800 dark:hover:text-zinc-300">
            {isRegister ? '¿Ya tienes cuenta? Inicia sesión' : '¿No tienes cuenta? Regístrate'}
          </button>
          <div className="border-t border-zinc-100 dark:border-zinc-800 pt-4 mt-1 text-center">
            <button onClick={() => { onLogin({ username: 'Invitado', isGuest: true }); }} className="text-[13px] text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 underline underline-offset-4 font-medium">Continuar como invitado</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function MainApp({ user, onLogout, theme, toggleTheme, appColor, setAppColor, colorTheme, showToast }: any) {
  const [currentView, setCurrentView] = useState('inicio');
  const [privacyMode, setPrivacyMode] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showIncomeModal, setShowIncomeModal] = useState(false);
  const [viewDate] = useState(new Date());

  const [appData, setAppData] = useLocalStorage(`misfinanzas_v8_${user.username}`, {
    income: { type: 'monthly', monthly: 2800000, daily: 90000 },
    expenses: [
      { id: 'e1', amount: 45000, cat: 'comida', desc: 'Almuerzo corrientazo', date: toISODate(new Date()), paymentMethod: 'Nequi' },
      { id: 'e2', amount: 12000, cat: 'transporte', desc: 'Bus SITP', date: toISODate(new Date()), paymentMethod: 'Efectivo' },
      { id: 'e3', amount: 35000, cat: 'ocio', desc: 'Cine + crispetas', date: toISODate(new Date(Date.now() - 86400000)), paymentMethod: 'Tarjeta' },
    ],
    rent: { total: 1200000, dueDay: 5, payments: [] as any[] },
    goals: [
      { id: 'g1', name: 'iPhone 15', target: 4000000, saved: 850000, contributions: [{ id: 'c1', amount: 850000, date: toISODate(new Date()) }] },
      { id: 'g2', name: 'Viaje Santa Marta', target: 1500000, saved: 300000, contributions: [] as any[] },
    ],
    workDays: [] as any[],
    subscriptions: [
      { id: 's1', name: 'Spotify', amount: 19900 },
      { id: 's2', name: 'Netflix', amount: 26900 },
    ],
    budgets: { comida: 600000, transporte: 200000, ocio: 300000, salud: 150000, otros: 200000 },
    debts: [
      { id: 'd1', name: 'Préstamo Bancolombia', amount: 2000000, payments: [{ id: 'p1', amount: 200000, date: toISODate(new Date()) }] }
    ]
  });

  const safeData = {
    ...appData,
    expenses: appData.expenses || [],
    subscriptions: appData.subscriptions || [],
    budgets: appData.budgets || { comida: 0, transporte: 0, ocio: 0, salud: 0, otros: 0 },
    goals: (appData.goals || []).map((g: any) => ({ ...g, contributions: g.contributions || [] })),
    debts: (appData.debts || []).map((d: any) => ({ ...d, payments: d.payments || [] })),
    rent: { ...appData.rent, payments: appData.rent.payments || [] },
    workDays: appData.workDays || [],
  };

  const updateData = (key: string, value: any) => setAppData((prev: any) => ({ ...prev, [key]: typeof value === 'function' ? value(prev[key]) : value }));

  const currentMonth = viewDate.getMonth();
  const currentYear = viewDate.getFullYear();
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const today = new Date();
  const isCurrentMonth = today.getMonth() === currentMonth && today.getFullYear() === currentYear;
  const currentDay = isCurrentMonth ? today.getDate() : daysInMonth;

  // CALCS with safe date parsing
  const totalIncome = safeData.income.type === 'monthly'
    ? safeData.income.monthly
    : safeData.workDays.filter((wd: any) => {
      if (!wd.worked) return false;
      const { y, m } = parseDateStr(wd.date);
      return y === currentYear && m === currentMonth + 1;
    }).length * safeData.income.daily;

  const rentTotal = safeData.rent.total || 0;
  const monthRentPayments = safeData.rent.payments.filter((p: any) => isSameMonth(p.date, currentMonth, currentYear));
  const rentPaidThisMonth = monthRentPayments.reduce((s: number, p: any) => s + p.amount, 0);
  const rentRemaining = Math.max(0, rentTotal - rentPaidThisMonth);
  const totalSubscriptions = safeData.subscriptions.reduce((s: number, sub: any) => s + sub.amount, 0);

  const monthExpenses = safeData.expenses.filter((e: any) => isSameMonth(e.date, currentMonth, currentYear));
  const totalExpenses = monthExpenses.reduce((s: number, e: any) => s + e.amount, 0);

  const monthGoalContributions = safeData.goals.reduce((total: number, goal: any) => {
    const monthContribs = goal.contributions.filter((c: any) => isSameMonth(c.date, currentMonth, currentYear));
    return total + monthContribs.reduce((s: number, c: any) => s + c.amount, 0);
  }, 0);
  const totalGoalsSaved = safeData.goals.reduce((s: number, g: any) => s + g.saved, 0);

  const monthDebtPayments = safeData.debts.reduce((total: number, debt: any) => {
    const monthPays = debt.payments.filter((p: any) => isSameMonth(p.date, currentMonth, currentYear));
    return total + monthPays.reduce((s: number, p: any) => s + p.amount, 0);
  }, 0);
  const totalPendingDebt = safeData.debts.reduce((total: number, debt: any) => {
    const paid = debt.payments.reduce((s: number, p: any) => s + p.amount, 0);
    return total + Math.max(0, debt.amount - paid);
  }, 0);

  const availableBalance = totalIncome - rentTotal - totalSubscriptions - totalExpenses - monthGoalContributions - monthDebtPayments;
  const idealSavings = totalIncome * 0.2;
  const pendingSavings = Math.max(0, idealSavings - monthGoalContributions);
  const freeMoney = availableBalance - pendingSavings;
  const netWorth = availableBalance + totalGoalsSaved - totalPendingDebt;

  const needsExpenses = monthExpenses.filter((e: any) => e.cat !== 'ocio').reduce((s: number, e: any) => s + e.amount, 0) + rentTotal + totalSubscriptions + monthDebtPayments;
  const wantsExpenses = monthExpenses.filter((e: any) => e.cat === 'ocio').reduce((s: number, e: any) => s + e.amount, 0);
  const savingsExpenses = monthGoalContributions;

  const isBlur = privacyMode ? 'blur-[8px] opacity-50 select-none' : 'transition-all duration-300';
  const hour = today.getHours();
  const greeting = hour < 12 ? 'Buenos días' : hour < 18 ? 'Buenas tardes' : 'Buenas noches';

  return (
    <div className="min-h-screen bg-[#f5f5f3] dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 flex justify-center">
      <div className="w-full max-w-md bg-white dark:bg-zinc-900 min-h-screen shadow-[0_0_80px_rgba(0,0,0,0.06)] relative flex flex-col pb-28 overflow-x-hidden border-x border-zinc-100 dark:border-zinc-800">

        <header className="sticky top-0 z-30 bg-white/85 dark:bg-zinc-900/85 backdrop-blur-2xl border-b border-zinc-100 dark:border-zinc-800">
          <div className="flex justify-between items-center px-5 py-3.5">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full flex justify-center items-center font-bold text-sm shadow-sm ring-1 ring-black/5 ${colorTheme.bg} ${colorTheme.text}`}>
                {user.username.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest">{greeting}</p>
                <p className="text-[15px] font-bold leading-tight tracking-tight">{user.username} {user.isGuest && <span className="text-[10px] font-medium bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded-full ml-1">Invitado</span>}</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button onClick={() => setPrivacyMode(!privacyMode)} className="w-9 h-9 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center hover:bg-zinc-200 dark:hover:bg-zinc-700 transition">
                {privacyMode ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
              <button onClick={() => setShowSettings(true)} className="w-9 h-9 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center hover:bg-zinc-200 dark:hover:bg-zinc-700 transition">
                <Settings size={16} />
              </button>
            </div>
          </div>
          <div className="px-5 pb-3 flex items-center gap-2 text-[11px] text-zinc-500 font-medium">
            <Calendar size={12} /> {viewDate.toLocaleDateString('es-CO', { month: 'long', year: 'numeric' })} • {currentDay}/{daysInMonth} días
            <div className="ml-auto flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> En vivo
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 py-4 space-y-5 overflow-y-auto no-scrollbar">
          {currentView === 'inicio' && (
            <Dashboard
              availableBalance={availableBalance}
              totalIncome={totalIncome}
              totalExpenses={totalExpenses}
              rentRemaining={rentRemaining}
              rentPaid={rentPaidThisMonth}
              rentTotal={rentTotal}
              isBlur={isBlur}
              daysInMonth={daysInMonth}
              currentDay={currentDay}
              monthExpenses={monthExpenses}
              colorTheme={colorTheme}
              netWorth={netWorth}
              freeMoney={freeMoney}
              idealSavings={idealSavings}
              needsExpenses={needsExpenses}
              wantsExpenses={wantsExpenses}
              savingsExpenses={savingsExpenses}
              showToast={showToast}
              setShowIncomeModal={setShowIncomeModal}
              totalSubscriptions={totalSubscriptions}
              monthGoalContributions={monthGoalContributions}
              currentMonth={currentMonth}
              currentYear={currentYear}
            />
          )}
          {currentView === 'gastos' && <Expenses expenses={safeData.expenses} subscriptions={safeData.subscriptions} budgets={safeData.budgets} updateData={updateData} isBlur={isBlur} colorTheme={colorTheme} showToast={showToast} currentMonth={currentMonth} currentYear={currentYear} />}
          {currentView === 'arriendo' && <Rent rent={safeData.rent} updateData={updateData} isBlur={isBlur} rentPaidThisMonth={rentPaidThisMonth} rentRemaining={rentRemaining} colorTheme={colorTheme} showToast={showToast} currentMonth={currentMonth} currentYear={currentYear} />}
          {currentView === 'metas' && <Goals goals={safeData.goals} updateData={updateData} isBlur={isBlur} colorTheme={colorTheme} showToast={showToast} />}
          {currentView === 'deudas' && <Debts debts={safeData.debts} updateData={updateData} isBlur={isBlur} colorTheme={colorTheme} showToast={showToast} />}
          {currentView === 'inversiones' && <Investments isBlur={isBlur} colorTheme={colorTheme} totalGoalsSaved={totalGoalsSaved} idealSavings={idealSavings} netWorth={netWorth} availableBalance={availableBalance} totalIncome={totalIncome} />}
          {currentView === 'ai' && <AiAssistant data={safeData} availableBalance={availableBalance} totalIncome={totalIncome} totalExpenses={totalExpenses} rentRemaining={rentRemaining} needsExpenses={needsExpenses} wantsExpenses={wantsExpenses} savingsExpenses={savingsExpenses} idealSavings={idealSavings} colorTheme={colorTheme} currentMonth={currentMonth} currentYear={currentYear} monthDebtPayments={monthDebtPayments} totalPendingDebt={totalPendingDebt} freeMoney={freeMoney} />}
        </main>

        <nav className="fixed bottom-5 left-1/2 -translate-x-1/2 w-[calc(100%-16px)] max-w-[420px] h-[64px] bg-zinc-900 dark:bg-white rounded-full flex items-center justify-between px-2 shadow-[0_20px_50px_rgba(0,0,0,0.25)] z-30">
          {[
            { id: 'inicio', icon: Home, label: 'Inicio' },
            { id: 'gastos', icon: Receipt, label: 'Gastos' },
            { id: 'arriendo', icon: Home, label: 'Casa' },
            { id: 'metas', icon: Target, label: 'Metas' },
            { id: 'deudas', icon: Wallet, label: 'Deudas' },
            { id: 'inversiones', icon: TrendingUp, label: 'Ahorro' },
            { id: 'ai', icon: Bot, label: 'M$ AI' }
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`flex flex-col items-center justify-center w-[14%] h-[52px] rounded-full transition-all duration-300 ${currentView === item.id ? `${colorTheme.activeNav} scale-105 shadow-md` : 'text-zinc-400 dark:text-zinc-500 hover:text-white dark:hover:text-black'}`}
            >
              <item.icon size={18} strokeWidth={currentView === item.id ? 2.5 : 2} />
              <span className="text-[8px] font-bold mt-1 tracking-wide truncate w-full text-center">{item.label}</span>
            </button>
          ))}
        </nav>

        {showIncomeModal && <IncomeWorkModal onClose={() => setShowIncomeModal(false)} appData={safeData} updateData={updateData} currentMonth={currentMonth} currentYear={currentYear} daysInMonth={daysInMonth} colorTheme={colorTheme} showToast={showToast} />}
        {showSettings && <SettingsModal onClose={() => setShowSettings(false)} onLogout={onLogout} user={user} appData={safeData} updateData={updateData} appColor={appColor} setAppColor={setAppColor} theme={theme} toggleTheme={toggleTheme} colorTheme={colorTheme} showToast={showToast} setAppData={setAppData} />}
      </div>
    </div>
  );
}

// --- DASHBOARD COMPLETO ---
function Dashboard({ availableBalance, totalIncome, totalExpenses, rentRemaining, rentPaid, rentTotal, isBlur, daysInMonth, currentDay, monthExpenses, colorTheme, netWorth, freeMoney, idealSavings, needsExpenses, wantsExpenses, savingsExpenses, showToast, setShowIncomeModal, totalSubscriptions, monthGoalContributions, currentMonth, currentYear }: any) {
  const chartData = useMemo(() => {
    const data = [];
    for (let i = 1; i <= daysInMonth; i++) {
      const dayTotal = monthExpenses.filter((e: any) => parseDateStr(e.date).d === i).reduce((sum: number, e: any) => sum + e.amount, 0);
      data.push({ day: i, amount: dayTotal });
    }
    return data;
  }, [monthExpenses, daysInMonth]);

  const totalIdealNeeds = totalIncome * 0.5;
  const totalIdealWants = totalIncome * 0.3;
  const totalIdealSavings = totalIncome * 0.2;

  const needsPct = totalIdealNeeds ? (needsExpenses / totalIdealNeeds) * 100 : 0;
  const wantsPct = totalIdealWants ? (wantsExpenses / totalIdealWants) * 100 : 0;
  const savingsPct = totalIdealSavings ? (savingsExpenses / totalIdealSavings) * 100 : 0;

  return (
    <div className="space-y-4 animate-[fadeIn_0.35s_ease]">
      <div className={`rounded-[28px] p-6 shadow-xl relative overflow-hidden ${colorTheme.bg} ${colorTheme.text}`}>
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/15 rounded-full blur-2xl" />
        <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-black/10 rounded-full blur-2xl" />
        <button onClick={() => setShowIncomeModal(true)} className="absolute top-4 right-4 w-9 h-9 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center backdrop-blur-md transition">
          <Briefcase size={16} />
        </button>
        <div className="relative z-10">
          <p className="text-[11px] font-bold tracking-widest uppercase opacity-80 mb-1 flex items-center gap-1.5"><span className="w-1.5 h-1.5 bg-white rounded-full" /> Balance disponible</p>
          <h2 className={`text-[32px] font-extrabold tracking-tight leading-none ${isBlur}`}>{formatCurrency(availableBalance)}</h2>
          <p className="text-[11px] opacity-70 mt-1.5 font-medium">Después de arriendo, gastos y ahorro</p>

          <div className="mt-5 grid grid-cols-2 gap-2.5">
            <div className="bg-white/15 backdrop-blur-xl rounded-2xl p-3 border border-white/10">
              <p className="text-[9px] uppercase font-bold tracking-widest opacity-70">Dinero libre real</p>
              <p className={`text-[15px] font-bold mt-1 ${freeMoney < 0 ? 'text-red-100' : ''} ${isBlur}`}>{formatCurrency(freeMoney)}</p>
              <p className="text-[10px] opacity-60 mt-0.5">{freeMoney < 0 ? '⚠️ Sobregasto' : 'Para gustos'}</p>
            </div>
            <div className="bg-black/15 backdrop-blur-xl rounded-2xl p-3 border border-white/10">
              <p className="text-[9px] uppercase font-bold tracking-widest opacity-70">Patrimonio total</p>
              <p className={`text-[15px] font-bold mt-1 ${isBlur}`}>{formatCurrency(netWorth)}</p>
              <p className="text-[10px] opacity-60 mt-0.5">Net worth</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: 'Ingresos', value: totalIncome, icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-900/20' },
          { label: 'Gastos', value: totalExpenses, icon: TrendingDown, color: 'text-rose-600', bg: 'bg-rose-50 dark:bg-rose-900/20' },
          { label: 'Arriendo restante', value: rentRemaining, icon: Home, color: 'text-sky-600', bg: 'bg-sky-50 dark:bg-sky-900/20' },
        ].map(card => (
          <div key={card.label} className="bg-white dark:bg-zinc-800/60 rounded-2xl p-3 border border-zinc-100 dark:border-zinc-800 shadow-sm">
            <div className={`w-7 h-7 rounded-full ${card.bg} flex items-center justify-center mb-2`}><card.icon size={14} className={card.color} /></div>
            <p className="text-[9px] font-bold uppercase tracking-widest text-zinc-500">{card.label}</p>
            <p className={`text-[13px] font-bold mt-1 ${isBlur}`}>{formatShortCurrency(card.value)}</p>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-[13px] font-bold flex items-center gap-2"><div className="w-6 h-6 rounded-full bg-zinc-900 dark:bg-white text-white dark:text-black flex items-center justify-center"><TrendingUp size={12} /></div> Gastos diarios</h3>
          <span className="text-[11px] font-medium text-zinc-500 bg-zinc-100 dark:bg-zinc-800 px-2.5 py-1 rounded-full">Día {currentDay} de {daysInMonth}</span>
        </div>
        <div className="h-[120px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorAmt" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={APP_COLORS.zinc.hex} stopOpacity={0.25} />
                  <stop offset="100%" stopColor={APP_COLORS.zinc.hex} stopOpacity={0} />
                </linearGradient>
              </defs>
              <Tooltip content={({ active, payload }: any) => active && payload?.[0] ? <div className="bg-zinc-900 text-white text-[11px] px-2.5 py-1.5 rounded-full font-bold">{`Día ${payload[0].payload.day}: ${formatCurrency(payload[0].value)}`}</div> : null} />
              <Area type="monotone" dataKey="amount" stroke="#18181b" strokeWidth={2} fill="url(#colorAmt)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <h3 className="text-[13px] font-bold mb-3 flex items-center gap-2"><PieChartIcon size={14} /> Análisis 50/30/20</h3>
        <div className="space-y-3.5">
          {[
            { label: 'Necesidades', real: needsExpenses, ideal: totalIdealNeeds, pct: needsPct, color: 'bg-sky-500', light: 'bg-sky-100' },
            { label: 'Gustos', real: wantsExpenses, ideal: totalIdealWants, pct: wantsPct, color: 'bg-violet-500', light: 'bg-violet-100' },
            { label: 'Ahorro', real: savingsExpenses, ideal: totalIdealSavings, pct: savingsPct, color: 'bg-emerald-500', light: 'bg-emerald-100' },
          ].map(row => (
            <div key={row.label} className="space-y-1.5">
              <div className="flex justify-between text-[11px] font-medium">
                <span className="font-bold">{row.label} <span className="font-normal text-zinc-500">({row.label === 'Necesidades' ? '50%' : row.label === 'Gustos' ? '30%' : '20%'})</span></span>
                <span className={`${isBlur} ${row.pct > 100 ? 'text-rose-600' : 'text-zinc-600 dark:text-zinc-400'}`}>{formatShortCurrency(row.real)} / {formatShortCurrency(row.ideal)} • {row.pct.toFixed(0)}%</span>
              </div>
              <div className={`h-2 rounded-full ${row.light} dark:bg-zinc-800 overflow-hidden`}>
                <div className={`h-full ${row.color} rounded-full transition-all`} style={{ width: `${Math.min(100, row.pct)}%` }} />
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 flex gap-2.5">
          <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0"><Lightbulb size={14} className="text-amber-600" /></div>
          <p className="text-[11px] leading-[1.4] text-zinc-600 dark:text-zinc-400">
            {needsPct > 100 ? 'Tus necesidades superan el 50%. Revisa arriendo y suscripciones.' : wantsPct > 100 ? 'Te pasaste en gustos este mes. Intenta recortar ocio.' : savingsPct < 80 ? `Te faltan ${formatCurrency(totalIdealSavings - savingsExpenses)} para tu meta de ahorro del 20%.` : '¡Excelente balance! Estás siguiendo la regla 50/30/20.'}
          </p>
        </div>
      </div>

      <div className="bg-zinc-900 dark:bg-white rounded-[22px] p-4 text-white dark:text-black">
        <p className="text-[11px] font-bold uppercase tracking-widest opacity-70 mb-2">Resumen mes</p>
        <div className="grid grid-cols-2 gap-3 text-[12px]">
          <div><p className="opacity-60">Arriendo pagado</p><p className="font-bold text-[13px] mt-0.5">{formatCurrency(rentPaid)} / {formatCurrency(rentTotal)}</p></div>
          <div><p className="opacity-60">Suscripciones</p><p className="font-bold text-[13px] mt-0.5">{formatCurrency(totalSubscriptions)}</p></div>
          <div><p className="opacity-60">Ahorro mes</p><p className="font-bold text-[13px] mt-0.5">{formatCurrency(monthGoalContributions)} / {formatCurrency(idealSavings)}</p></div>
          <div><p className="opacity-60">Gastos totales</p><p className="font-bold text-[13px] mt-0.5">{formatCurrency(totalExpenses)}</p></div>
        </div>
      </div>
    </div>
  );
}

// --- EXPENSES ---
function Expenses({ expenses, subscriptions, budgets, updateData, isBlur, colorTheme, showToast, currentMonth, currentYear }: any) {
  const [form, setForm] = useState({ amount: '', cat: 'comida', desc: '', paymentMethod: 'Nequi', date: toISODate(new Date()) });
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState('all');
  const [editingBudgets, setEditingBudgets] = useState(false);
  const [localBudgets, setLocalBudgets] = useState(budgets);
  const [subForm, setSubForm] = useState({ name: '', amount: '' });

  const monthExpenses = expenses.filter((e: any) => isSameMonth(e.date, currentMonth, currentYear));
  const filtered = monthExpenses.filter((e: any) => {
    const matchSearch = e.desc.toLowerCase().includes(search.toLowerCase());
    const matchCat = filterCat === 'all' || e.cat === filterCat;
    return matchSearch && matchCat;
  });

  const catTotals = CAT_KEYS.map(cat => ({
    cat,
    total: monthExpenses.filter((e: any) => e.cat === cat).reduce((s: number, e: any) => s + e.amount, 0),
    label: (CATEGORIES as any)[cat].label,
    color: (CATEGORIES as any)[cat].dot
  }));

  const pieData = catTotals.filter(c => c.total > 0).map(c => ({ name: c.label, value: c.total, color: c.color === 'bg-emerald-500' ? '#10b981' : c.color === 'bg-sky-500' ? '#0ea5e9' : c.color === 'bg-violet-500' ? '#8b5cf6' : c.color === 'bg-rose-500' ? '#f43f5e' : '#71717a' }));

  const addExpense = () => {
    if (!form.amount || Number(form.amount) <= 0) { showToast('Monto inválido'); return; }
    const newExp = { id: Date.now().toString(), amount: Number(form.amount), cat: form.cat, desc: form.desc || (CATEGORIES as any)[form.cat].label, date: form.date, paymentMethod: form.paymentMethod };
    updateData('expenses', (prev: any[]) => [newExp, ...prev]);
    setForm({ amount: '', cat: 'comida', desc: '', paymentMethod: 'Nequi', date: toISODate(new Date()) });
    showToast('Gasto agregado');
  };

  return (
    <div className="space-y-4 animate-[fadeIn_0.35s_ease]">
      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <h3 className="font-bold text-[15px] mb-3">Agregar gasto</h3>
        <div className="grid grid-cols-2 gap-2.5">
          <div className="col-span-2 relative">
            <DollarSign size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input type="number" placeholder="Monto" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} className="w-full h-11 pl-9 pr-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-transparent focus:border-zinc-900 dark:focus:border-white outline-none text-[14px] font-semibold" />
          </div>
          <div className="col-span-2 grid grid-cols-5 gap-1.5">
            {CAT_KEYS.map(cat => {
              const C = (CATEGORIES as any)[cat];
              const active = form.cat === cat;
              return (
                <button key={cat} onClick={() => setForm({ ...form, cat })} className={`h-16 rounded-2xl border flex flex-col items-center justify-center gap-1 transition ${active ? 'border-zinc-900 dark:border-white bg-zinc-900 dark:bg-white text-white dark:text-black' : 'border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900'}`}>
                  <C.icon size={16} /><span className="text-[9px] font-bold">{C.label}</span>
                </button>
              );
            })}
          </div>
          <input placeholder="Descripción" value={form.desc} onChange={e => setForm({ ...form, desc: e.target.value })} className="h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-transparent focus:border-zinc-900 dark:focus:border-white outline-none text-[13px] col-span-2" />
          <select value={form.paymentMethod} onChange={e => setForm({ ...form, paymentMethod: e.target.value })} className="h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-transparent outline-none text-[13px]">{PAYMENT_METHODS.map(m => <option key={m} value={m}>{m}</option>)}</select>
          <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className="h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-transparent outline-none text-[13px]" />
        </div>
        <button onClick={addExpense} className={`mt-3 w-full h-11 rounded-xl font-bold text-[14px] flex items-center justify-center gap-2 ${colorTheme.bg} ${colorTheme.text}`}><Plus size={16} /> Agregar gasto</button>
      </div>

      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <div className="flex gap-2 mb-3">
          <div className="flex-1 relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input placeholder="Buscar..." value={search} onChange={e => setSearch(e.target.value)} className="w-full h-9 pl-8 pr-3 rounded-full bg-zinc-100 dark:bg-zinc-900 text-[12px] outline-none" />
          </div>
          <select value={filterCat} onChange={e => setFilterCat(e.target.value)} className="h-9 px-3 rounded-full bg-zinc-100 dark:bg-zinc-900 text-[12px] font-medium outline-none">
            <option value="all">Todas</option>{CAT_KEYS.map(c => <option key={c} value={c}>{(CATEGORIES as any)[c].label}</option>)}
          </select>
        </div>
        <div className="space-y-2 max-h-[280px] overflow-y-auto no-scrollbar">
          {filtered.length === 0 ? <p className="text-[12px] text-zinc-500 text-center py-6">Sin gastos este mes</p> : filtered.map((e: any) => {
            const cat = (CATEGORIES as any)[e.cat];
            const Icon = cat.icon;
            return (
              <div key={e.id} className="flex items-center gap-3 p-2.5 rounded-2xl hover:bg-zinc-50 dark:hover:bg-zinc-900 transition border border-transparent hover:border-zinc-100 dark:hover:border-zinc-800">
                <div className={`w-9 h-9 rounded-full ${cat.bg} flex items-center justify-center`}><Icon size={14} className={cat.color} /></div>
                <div className="flex-1 min-w-0">
                  <p className="text-[13px] font-semibold truncate">{e.desc}</p>
                  <p className="text-[10px] text-zinc-500">{parseDateStr(e.date).d}/{parseDateStr(e.date).m} • {e.paymentMethod} • {cat.label}</p>
                </div>
                <p className={`text-[13px] font-bold ${isBlur}`}>{formatCurrency(e.amount)}</p>
                <button onClick={() => { updateData('expenses', (prev: any[]) => prev.filter((x: any) => x.id !== e.id)); showToast('Gasto eliminado'); }} className="w-7 h-7 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center"><Trash2 size={12} /></button>
              </div>
            );
          })}
        </div>
      </div>

      {pieData.length > 0 && (
        <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
          <h4 className="font-bold text-[13px] mb-3 flex items-center gap-2"><PieChartIcon size={14} /> Por categoría</h4>
          <div className="h-[160px] flex items-center">
            <div className="flex-1 h-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} dataKey="value" cx="50%" cy="50%" innerRadius={40} outerRadius={60} paddingAngle={3}>
                    {pieData.map((entry: any, idx: number) => <Cell key={idx} fill={entry.color} />)}
                  </Pie>
                  <Tooltip content={({ active, payload }: any) => active && payload?.[0] ? <div className="bg-zinc-900 text-white text-[11px] px-2 py-1 rounded-full">{payload[0].name}: {formatCurrency(payload[0].value)}</div> : null} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-1.5 w-[110px]">
              {catTotals.filter(c => c.total > 0).map(c => (
                <div key={c.cat} className="flex items-center gap-2 text-[11px]"><span className={`w-2 h-2 rounded-full ${c.color}`} /><span className="font-medium">{c.label}</span><span className={`ml-auto font-bold ${isBlur}`}>{formatShortCurrency(c.total)}</span></div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <div className="flex justify-between items-center mb-3">
          <h4 className="font-bold text-[13px]">Presupuestos mensuales</h4>
          <button onClick={() => { if (editingBudgets) { updateData('budgets', localBudgets); showToast('Presupuestos guardados'); } setEditingBudgets(!editingBudgets); }} className={`text-[11px] font-bold px-3 py-1 rounded-full ${editingBudgets ? 'bg-zinc-900 dark:bg-white text-white dark:text-black' : 'bg-zinc-100 dark:bg-zinc-800'}`}>{editingBudgets ? 'Guardar' : 'Editar'}</button>
        </div>
        <div className="grid grid-cols-2 gap-2.5">
          {CAT_KEYS.map(cat => {
            const spent = monthExpenses.filter((e: any) => e.cat === cat).reduce((s: number, e: any) => s + e.amount, 0);
            const budget = localBudgets[cat] || 0;
            const pct = budget ? (spent / budget) * 100 : 0;
            return (
              <div key={cat} className="p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800">
                <div className="flex justify-between items-center mb-1"><span className="text-[11px] font-bold">{(CATEGORIES as any)[cat].label}</span><span className={`text-[10px] ${pct > 100 ? 'text-rose-600' : 'text-zinc-500'}`}>{pct.toFixed(0)}%</span></div>
                {editingBudgets ? (
                  <input type="number" value={localBudgets[cat]} onChange={e => setLocalBudgets({ ...localBudgets, [cat]: Number(e.target.value) })} className="w-full h-8 px-2 rounded-lg bg-white dark:bg-zinc-800 border text-[12px]" />
                ) : (
                  <>
                    <div className="h-1.5 rounded-full bg-zinc-200 dark:bg-zinc-800 overflow-hidden"><div className={`h-full ${pct > 100 ? 'bg-rose-500' : 'bg-zinc-900 dark:bg-white'}`} style={{ width: `${Math.min(100, pct)}%` }} /></div>
                    <p className={`text-[11px] mt-1 font-medium ${isBlur}`}>{formatShortCurrency(spent)} / {formatShortCurrency(budget)}</p>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <h4 className="font-bold text-[13px] mb-3">Suscripciones fijas</h4>
        <div className="space-y-2 mb-3">
          {subscriptions.map((s: any) => (
            <div key={s.id} className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-900">
              <span className="text-[13px] font-medium">{s.name}</span>
              <div className="flex items-center gap-2"><span className={`text-[12px] font-bold ${isBlur}`}>{formatCurrency(s.amount)}</span><button onClick={() => { updateData('subscriptions', (prev: any[]) => prev.filter((x: any) => x.id !== s.id)); showToast('Suscripción eliminada'); }} className="w-6 h-6 rounded-full bg-white dark:bg-zinc-800 flex items-center justify-center"><X size={10} /></button></div>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input placeholder="Nombre" value={subForm.name} onChange={e => setSubForm({ ...subForm, name: e.target.value })} className="flex-1 h-9 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 text-[12px] outline-none" />
          <input type="number" placeholder="Monto" value={subForm.amount} onChange={e => setSubForm({ ...subForm, amount: e.target.value })} className="w-24 h-9 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 text-[12px] outline-none" />
          <button onClick={() => {
            if (!subForm.name || !subForm.amount) { showToast('Completa datos'); return; }
            updateData('subscriptions', (prev: any[]) => [...prev, { id: Date.now().toString(), name: subForm.name, amount: Number(subForm.amount) }]);
            setSubForm({ name: '', amount: '' }); showToast('Suscripción agregada');
          }} className={`w-9 h-9 rounded-xl flex items-center justify-center ${colorTheme.bg} ${colorTheme.text}`}><Plus size={14} /></button>
        </div>
      </div>
    </div>
  );
}

function Rent({ rent, updateData, isBlur, rentPaidThisMonth, rentRemaining, colorTheme, showToast, currentMonth, currentYear }: any) {
  const [total, setTotal] = useState(rent.total.toString());
  const [dueDay, setDueDay] = useState(rent.dueDay.toString());
  const [payAmount, setPayAmount] = useState('');
  const [payDate, setPayDate] = useState(toISODate(new Date()));

  const monthPayments = rent.payments.filter((p: any) => isSameMonth(p.date, currentMonth, currentYear));
  const progress = rent.total ? (rentPaidThisMonth / rent.total) * 100 : 0;

  const saveConfig = () => {
    updateData('rent', (prev: any) => ({ ...prev, total: Number(total), dueDay: Number(dueDay) }));
    showToast('Configuración guardada');
  };

  return (
    <div className="space-y-4 animate-[fadeIn_0.35s_ease]">
      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <h3 className="font-bold text-[15px] mb-3">Configuración arriendo</h3>
        <div className="grid grid-cols-2 gap-2.5">
          <div><label className="text-[11px] font-bold text-zinc-500">Total arriendo</label><input type="number" value={total} onChange={e => setTotal(e.target.value)} className="mt-1 w-full h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 outline-none text-[14px] font-semibold" /></div>
          <div><label className="text-[11px] font-bold text-zinc-500">Día vencimiento</label><input type="number" min={1} max={31} value={dueDay} onChange={e => setDueDay(e.target.value)} className="mt-1 w-full h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 outline-none text-[14px] font-semibold" /></div>
        </div>
        <button onClick={saveConfig} className={`mt-3 w-full h-11 rounded-xl font-bold text-[13px] ${colorTheme.bg} ${colorTheme.text}`}>Guardar configuración</button>
      </div>

      <div className={`rounded-[22px] p-5 text-white ${progress >= 100 ? 'bg-emerald-600' : progress > 0 ? 'bg-amber-500' : 'bg-zinc-900 dark:bg-white dark:text-black'}`}>
        <div className="flex justify-between items-start">
          <div><p className="text-[11px] uppercase font-bold tracking-widest opacity-70">Progreso arriendo</p><p className="text-[22px] font-extrabold mt-1">{progress.toFixed(0)}% pagado</p></div>
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"><Home size={18} /></div>
        </div>
        <div className="mt-4 h-2.5 rounded-full bg-white/20 overflow-hidden"><div className="h-full bg-white rounded-full transition-all" style={{ width: `${Math.min(100, progress)}%` }} /></div>
        <div className="mt-3 flex justify-between text-[12px] font-medium"><span className={isBlur}>{formatCurrency(rentPaidThisMonth)} pagado</span><span className={isBlur}>{formatCurrency(rentRemaining)} restante</span></div>
        {rentRemaining === 0 && rent.total > 0 && <p className="mt-2 text-[11px] bg-white/20 rounded-full px-3 py-1 inline-block font-bold">✅ Arriendo al día</p>}
      </div>

      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <h4 className="font-bold text-[13px] mb-3">Agregar pago</h4>
        <div className="flex gap-2">
          <input type="number" placeholder="Monto" value={payAmount} onChange={e => setPayAmount(e.target.value)} className="flex-1 h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 outline-none text-[13px] font-semibold" />
          <input type="date" value={payDate} onChange={e => setPayDate(e.target.value)} className="w-[140px] h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 outline-none text-[13px]" />
        </div>
        <button onClick={() => {
          if (!payAmount || Number(payAmount) <= 0) { showToast('Monto inválido'); return; }
          const p = { id: Date.now().toString(), amount: Number(payAmount), date: payDate };
          updateData('rent', (prev: any) => ({ ...prev, payments: [...prev.payments, p] }));
          setPayAmount(''); showToast('Pago agregado');
        }} className={`mt-2.5 w-full h-11 rounded-xl font-bold text-[13px] flex items-center justify-center gap-2 ${colorTheme.bg} ${colorTheme.text}`}><Plus size={14} /> Registrar pago</button>
      </div>

      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <h4 className="font-bold text-[13px] mb-3">Pagos del mes ({monthPayments.length})</h4>
        <div className="space-y-2">
          {monthPayments.length === 0 ? <p className="text-[12px] text-zinc-500 text-center py-4">Sin pagos registrados</p> :
            monthPayments.map((p: any) => (
              <div key={p.id} className="flex items-center justify-between p-3 rounded-xl bg-zinc-50 dark:bg-zinc-900">
                <div><p className={`text-[13px] font-bold ${isBlur}`}>{formatCurrency(p.amount)}</p><p className="text-[10px] text-zinc-500">{p.date} • Día {parseDateStr(p.date).d}</p></div>
                <button onClick={() => { updateData('rent', (prev: any) => ({ ...prev, payments: prev.payments.filter((x: any) => x.id !== p.id) })); showToast('Pago eliminado'); }} className="w-7 h-7 rounded-full bg-white dark:bg-zinc-800 flex items-center justify-center"><Trash2 size={12} /></button>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}

function Goals({ goals, updateData, isBlur, colorTheme, showToast }: any) {
  const [form, setForm] = useState({ name: '', target: '' });
  const [contrib, setContrib] = useState<Record<string, string>>({});

  const addGoal = () => {
    if (!form.name || !form.target || Number(form.target) <= 0) { showToast('Completa nombre y meta'); return; }
    updateData('goals', (prev: any[]) => [...prev, { id: Date.now().toString(), name: form.name, target: Number(form.target), saved: 0, contributions: [] }]);
    setForm({ name: '', target: '' }); showToast('Meta creada');
  };

  return (
    <div className="space-y-4 animate-[fadeIn_0.35s_ease]">
      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <h3 className="font-bold text-[15px] mb-3">Nueva meta</h3>
        <div className="flex gap-2">
          <input placeholder="Ej: Viaje a Cartagena" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="flex-1 h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 outline-none text-[13px]" />
          <input type="number" placeholder="Meta COP" value={form.target} onChange={e => setForm({ ...form, target: e.target.value })} className="w-32 h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 outline-none text-[13px] font-semibold" />
        </div>
        <button onClick={addGoal} className={`mt-2.5 w-full h-11 rounded-xl font-bold text-[13px] ${colorTheme.bg} ${colorTheme.text}`}>Crear meta</button>
      </div>

      <div className="grid gap-3">
        {goals.length === 0 && <p className="text-[12px] text-zinc-500 text-center py-8 bg-white dark:bg-zinc-800/60 rounded-[22px] border border-zinc-100 dark:border-zinc-800">No tienes metas aún. ¡Crea la primera!</p>}
        {goals.map((g: any) => {
          const pct = g.target ? (g.saved / g.target) * 100 : 0;
          return (
            <div key={g.id} className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
              <div className="flex justify-between items-start">
                <div><p className="font-bold text-[14px]">{g.name}</p><p className={`text-[12px] text-zinc-500 ${isBlur}`}>{formatCurrency(g.saved)} / {formatCurrency(g.target)}</p></div>
                <button onClick={() => { updateData('goals', (prev: any[]) => prev.filter((x: any) => x.id !== g.id)); showToast('Meta eliminada'); }} className="w-7 h-7 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center"><Trash2 size={12} /></button>
              </div>
              <div className="mt-3 h-2.5 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden"><div className="h-full bg-zinc-900 dark:bg-white rounded-full transition-all" style={{ width: `${Math.min(100, pct)}%` }} /></div>
              <p className="text-[10px] font-bold mt-1.5 text-zinc-500">{pct.toFixed(1)}% completado • Falta {formatCurrency(Math.max(0, g.target - g.saved))}</p>

              <div className="mt-3 flex gap-2">
                <input type="number" placeholder="Aporte" value={contrib[g.id] || ''} onChange={e => setContrib({ ...contrib, [g.id]: e.target.value })} className="flex-1 h-9 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 outline-none text-[12px]" />
                <button onClick={() => {
                  const amt = Number(contrib[g.id]);
                  if (!amt || amt <= 0) { showToast('Monto inválido'); return; }
                  updateData('goals', (prev: any[]) => prev.map((goal: any) => goal.id === g.id ? { ...goal, saved: goal.saved + amt, contributions: [...goal.contributions, { id: Date.now().toString(), amount: amt, date: toISODate(new Date()) }] } : goal));
                  setContrib({ ...contrib, [g.id]: '' }); showToast('Aporte agregado');
                }} className={`px-4 h-9 rounded-xl text-[12px] font-bold ${colorTheme.bg} ${colorTheme.text}`}>Aportar</button>
              </div>

              {g.contributions.length > 0 && (
                <div className="mt-3 pt-3 border-t border-zinc-100 dark:border-zinc-800 space-y-1 max-h-[100px] overflow-y-auto">
                  {g.contributions.slice(-5).reverse().map((c: any) => (
                    <div key={c.id} className="flex justify-between text-[11px]"><span className="text-zinc-500">{c.date}</span><span className={`font-bold ${isBlur}`}>+{formatCurrency(c.amount)}</span></div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Debts({ debts, updateData, isBlur, colorTheme, showToast }: any) {
  const [form, setForm] = useState({ name: '', amount: '' });
  const [payForm, setPayForm] = useState<Record<string, string>>({});

  return (
    <div className="space-y-4 animate-[fadeIn_0.35s_ease]">
      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <h3 className="font-bold text-[15px] mb-3">Nueva deuda</h3>
        <div className="flex gap-2">
          <input placeholder="Ej: Tarjeta Éxito" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="flex-1 h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 outline-none text-[13px]" />
          <input type="number" placeholder="Monto" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} className="w-32 h-11 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 outline-none text-[13px] font-semibold" />
        </div>
        <button onClick={() => {
          if (!form.name || !form.amount) { showToast('Completa datos'); return; }
          updateData('debts', (prev: any[]) => [...prev, { id: Date.now().toString(), name: form.name, amount: Number(form.amount), payments: [] }]);
          setForm({ name: '', amount: '' }); showToast('Deuda agregada');
        }} className={`mt-2.5 w-full h-11 rounded-xl font-bold text-[13px] ${colorTheme.bg} ${colorTheme.text}`}>Agregar deuda</button>
      </div>

      <div className="grid gap-3">
        {debts.length === 0 && <p className="text-[12px] text-zinc-500 text-center py-8 bg-white dark:bg-zinc-800/60 rounded-[22px] border">Sin deudas registradas 🎉</p>}
        {debts.map((d: any) => {
          const paid = d.payments.reduce((s: number, p: any) => s + p.amount, 0);
          const pending = Math.max(0, d.amount - paid);
          const pct = d.amount ? (paid / d.amount) * 100 : 0;
          return (
            <div key={d.id} className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
              <div className="flex justify-between items-start">
                <div><p className="font-bold text-[14px]">{d.name}</p><p className={`text-[11px] text-zinc-500 ${isBlur}`}>Total {formatCurrency(d.amount)} • Pagado {formatCurrency(paid)}</p></div>
                <button onClick={() => { updateData('debts', (prev: any[]) => prev.filter((x: any) => x.id !== d.id)); showToast('Deuda eliminada'); }} className="w-7 h-7 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center"><Trash2 size={12} /></button>
              </div>
              <div className="mt-3 h-2.5 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden"><div className="h-full bg-rose-500 rounded-full" style={{ width: `${Math.min(100, pct)}%` }} /></div>
              <div className="flex justify-between mt-2 text-[11px]"><span className="font-bold text-rose-600">Pendiente: {formatCurrency(pending)}</span><span className="text-zinc-500">{pct.toFixed(0)}% pagado</span></div>

              <div className="mt-3 flex gap-2">
                <input type="number" placeholder="Abono" value={payForm[d.id] || ''} onChange={e => setPayForm({ ...payForm, [d.id]: e.target.value })} className="flex-1 h-9 px-3 rounded-xl bg-zinc-100 dark:bg-zinc-900 outline-none text-[12px]" />
                <button onClick={() => {
                  const amt = Number(payForm[d.id]);
                  if (!amt || amt <= 0) { showToast('Monto inválido'); return; }
                  updateData('debts', (prev: any[]) => prev.map((debt: any) => debt.id === d.id ? { ...debt, payments: [...debt.payments, { id: Date.now().toString(), amount: amt, date: toISODate(new Date()) }] } : debt));
                  setPayForm({ ...payForm, [d.id]: '' }); showToast('Abono registrado');
                }} className="px-4 h-9 rounded-xl text-[12px] font-bold bg-zinc-900 dark:bg-white text-white dark:text-black">Abonar</button>
              </div>

              {d.payments.length > 0 && (
                <div className="mt-3 pt-3 border-t border-zinc-100 dark:border-zinc-800 space-y-1">
                  {d.payments.slice(-4).reverse().map((p: any) => (
                    <div key={p.id} className="flex justify-between text-[11px]"><span className="text-zinc-500">{p.date}</span><span className={`font-bold ${isBlur}`}>-{formatCurrency(p.amount)}</span></div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Investments({ isBlur, colorTheme, totalGoalsSaved, idealSavings, netWorth, availableBalance, totalIncome }: any) {
  const growthData = useMemo(() => {
    return Array.from({ length: 12 }, (_, i) => ({
      mes: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'][i],
      ahorro: Math.round(totalGoalsSaved * (0.4 + (i / 12) * 0.8) + Math.random() * 50000),
      ideal: Math.round(idealSavings * (i + 1))
    }));
  }, [totalGoalsSaved, idealSavings]);

  const monthlyRate = totalIncome ? (idealSavings / totalIncome) * 100 : 0;

  return (
    <div className="space-y-4 animate-[fadeIn_0.35s_ease]">
      <div className={`rounded-[22px] p-5 ${colorTheme.bg} ${colorTheme.text} shadow-lg`}>
        <p className="text-[11px] uppercase font-bold tracking-widest opacity-70">Ahorro acumulado</p>
        <p className={`text-[26px] font-extrabold mt-1 ${isBlur}`}>{formatCurrency(totalGoalsSaved)}</p>
        <div className="mt-3 flex gap-2 text-[11px]">
          <span className="bg-white/20 px-2.5 py-1 rounded-full font-medium">Net worth {formatShortCurrency(netWorth)}</span>
          <span className="bg-black/15 px-2.5 py-1 rounded-full font-medium">Tasa ahorro {monthlyRate.toFixed(0)}%</span>
        </div>
      </div>

      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <h4 className="font-bold text-[13px] mb-3 flex items-center gap-2"><TrendingUp size={14} /> Proyección anual (simulado)</h4>
        <div className="h-[160px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={growthData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e4e4e7" opacity={0.5} />
              <XAxis dataKey="mes" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v: number) => formatShortCurrency(v)} width={50} />
              <Tooltip content={({ active, payload }: any) => active && payload?.[0] ? <div className="bg-zinc-900 text-white text-[11px] px-3 py-1.5 rounded-full font-bold">{formatCurrency(payload[0].value)}</div> : null} />
              <Bar dataKey="ahorro" fill={APP_COLORS.zinc.hex} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm">
        <h4 className="font-bold text-[13px] mb-3 flex items-center gap-2"><Lightbulb size={14} className="text-amber-500" /> Regla 50/30/20 - Guía neobanco</h4>
        <div className="space-y-3 text-[12px] leading-[1.5]">
          <div className="p-3 rounded-2xl bg-sky-50 dark:bg-sky-900/20 border border-sky-100 dark:border-sky-900/30"><p className="font-bold text-sky-700 dark:text-sky-300">50% Necesidades</p><p className="text-zinc-600 dark:text-zinc-400 mt-1">Arriendo, comida, transporte, servicios, salud, deudas. Si superas el 50%, recorta suscripciones o busca arriendo más barato.</p></div>
          <div className="p-3 rounded-2xl bg-violet-50 dark:bg-violet-900/20 border border-violet-100 dark:border-violet-900/30"><p className="font-bold text-violet-700 dark:text-violet-300">30% Gustos</p><p className="text-zinc-600 dark:text-zinc-400 mt-1">Ocio, restaurantes, ropa, viajes cortos. Tu colchón de felicidad. Controla con presupuestos en la pestaña Gastos.</p></div>
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-900/30"><p className="font-bold text-emerald-700 dark:text-emerald-300">20% Ahorro / Inversión</p><p className="text-zinc-600 dark:text-zinc-400 mt-1">Metas, fondo emergencia (3-6 meses de gastos), CDT, inversiones. Automatiza: paga tu ahorro primero, como si fuera arriendo.</p></div>
        </div>
      </div>

      <div className="bg-zinc-900 dark:bg-white rounded-[22px] p-4 text-white dark:text-black">
        <p className="text-[12px] font-bold flex items-center gap-2"><Sparkles size={14} /> Tips rápidos para Colombia</p>
        <ul className="mt-2 space-y-1.5 text-[11px] opacity-80 list-disc ml-4">
          <li>Fondo de emergencia en Nequi/Bancolombia con rentabilidad diaria.</li>
          <li>CDT digital: compara tasas en tu banco antes de invertir.</li>
          <li>Evita gota a gota y tarjetas con 30%+ E.A. Prioriza pagar deudas caras.</li>
          <li>Usa Daviplata/Nequi bolsillos para separar tu 20% de ahorro.</li>
        </ul>
      </div>
    </div>
  );
}

function AiAssistant({ data, availableBalance, totalIncome, totalExpenses, needsExpenses, wantsExpenses, savingsExpenses, idealSavings, colorTheme, freeMoney, totalPendingDebt }: any) {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: `¡Hola! Soy M$ AI 🤖\n\nVi tus números: Ingresos ${formatCurrency(totalIncome)}, Gastos ${formatCurrency(totalExpenses)}, Disponible ${formatCurrency(availableBalance)}, Libre ${formatCurrency(freeMoney)}.\n\nPregúntame: "¿cómo ahorro más?", "analiza mis gastos" o "consejo para deudas".` }
  ]);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const generateAdvice = (q: string) => {
    const lower = q.toLowerCase();
    const needsPct = totalIncome ? (needsExpenses / totalIncome) * 100 : 0;
    const wantsPct = totalIncome ? (wantsExpenses / totalIncome) * 100 : 0;
    const savingsPct = totalIncome ? (savingsExpenses / totalIncome) * 100 : 0;

    if (lower.includes('gasto') || lower.includes('analiza')) {
      return `📊 **Análisis de gastos:**\n- Necesidades: ${formatCurrency(needsExpenses)} (${needsPct.toFixed(0)}% del ingreso, ideal 50%)\n- Gustos: ${formatCurrency(wantsExpenses)} (${wantsPct.toFixed(0)}%, ideal 30%)\n- Ahorro: ${formatCurrency(savingsExpenses)} (${savingsPct.toFixed(0)}%, ideal 20%)\n\n${needsPct > 55 ? '⚠️ Necesidades altas. Revisa arriendo y suscripciones.' : wantsPct > 35 ? '🎮 Gustos altos. Recorta ocio 1 semana.' : '✅ Balance bastante bueno!'}\n\nTop categorías este mes: ${Object.entries(
        data.expenses.filter((e: any) => isSameMonth(e.date, new Date().getMonth(), new Date().getFullYear()))
          .reduce((acc: any, e: any) => ({ ...acc, [e.cat]: (acc[e.cat] || 0) + e.amount }), {})
      ).sort((a: any, b: any) => b[1] - a[1]).slice(0, 2).map(([k, v]: any) => `${(CATEGORIES as any)[k].label} ${formatCurrency(v as number)}`).join(', ') || 'sin datos'}.`;
    }
    if (lower.includes('deuda')) {
      return `💳 **Deudas:** Pendiente ${formatCurrency(totalPendingDebt)}. \nEstrategia bola de nieve: paga primero la deuda más pequeña para ganar motivación, luego ataca la más cara (interés alto).\nSi ${formatCurrency(totalPendingDebt)} > 40% de ${formatCurrency(totalIncome)}, evita nuevas deudas este mes y destina tu dinero libre ${formatCurrency(freeMoney)} a abonos.`;
    }
    if (lower.includes('ahorro') || lower.includes('ahorrar')) {
      return `💰 **Cómo ahorrar más:**\n1. Automatiza tu 20%: ${formatCurrency(idealSavings)}/mes a Nequi bolsillo el día que te pagan.\n2. Recorta ${formatCurrency(Math.max(0, wantsExpenses - totalIncome * 0.3))} en ocio si te pasaste del 30%.\n3. Revisa suscripciones: ${data.subscriptions.length} activas = ${formatCurrency(data.subscriptions.reduce((s: number, x: any) => s + x.amount, 0))}.\n4. Fondo emergencia: meta ${formatCurrency(totalIncome * 3)} (3 meses). Llevas ${formatCurrency(data.goals.reduce((s: number, g: any) => s + g.saved, 0))}.`;
    }
    if (lower.includes('arriendo')) {
      return `🏠 Arriendo: ideal <30% de ingresos. Tu arriendo ${formatCurrency(data.rent.total)} es ${totalIncome ? ((data.rent.total / totalIncome) * 100).toFixed(0) : 0}% de ${formatCurrency(totalIncome)}. ${data.rent.total / totalIncome > 0.4 ? 'Está alto para Colombia, considera compartir o renegociar.' : 'Está en rango saludable.'}`;
    }
    return `🤖 Entendido: "${q}"\n\nCon ${formatCurrency(totalIncome)} de ingreso, tu flujo real es ${formatCurrency(availableBalance)} disponible y ${formatCurrency(freeMoney)} libre.\n\nRecomendación rápida:\n- Guarda ${formatCurrency(idealSavings)} este mes (20%)\n- Mantén necesidades < ${formatCurrency(totalIncome * 0.5)}\n- Gustos < ${formatCurrency(totalIncome * 0.3)}\n\nPregunta: "analiza mis gastos", "consejo deudas" o "cómo ahorro".`;
  };

  const send = () => {
    if (!input.trim()) return;
    const userMsg = { role: 'user' as const, text: input };
    const aiMsg = { role: 'ai' as const, text: generateAdvice(input) };
    setMessages(prev => [...prev, userMsg, aiMsg]);
    setInput('');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] animate-[fadeIn_0.35s_ease]">
      <div className="bg-white dark:bg-zinc-800/60 rounded-[22px] p-4 border border-zinc-100 dark:border-zinc-800 shadow-sm mb-3">
        <div className="flex items-center gap-2"><div className={`w-8 h-8 rounded-full ${colorTheme.bg} ${colorTheme.text} flex items-center justify-center`}><Bot size={16} /></div><div><p className="text-[13px] font-bold">M$ AI • Asesor local</p><p className="text-[10px] text-zinc-500">Sin API, 100% privado, datos en tu celular</p></div><div className="ml-auto w-2 h-2 bg-emerald-500 rounded-full animate-pulse" /></div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 no-scrollbar pr-1">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-[18px] px-4 py-3 text-[12px] leading-[1.5] whitespace-pre-wrap ${m.role === 'user' ? `${colorTheme.bg} ${colorTheme.text} rounded-br-[6px]` : 'bg-white dark:bg-zinc-800 border border-zinc-100 dark:border-zinc-800 rounded-bl-[6px]'}`}>
              {m.text}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <div className="mt-3 flex gap-2">
        <div className="flex-1 relative">
          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Ej: ¿cómo ahorro más?" className="w-full h-11 pl-4 pr-10 rounded-full bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 outline-none text-[13px] focus:border-zinc-900 dark:focus:border-white" />
          <button onClick={send} className={`absolute right-1 top-1 w-9 h-9 rounded-full flex items-center justify-center ${colorTheme.bg} ${colorTheme.text}`}><ArrowUpRight size={16} /></button>
        </div>
      </div>
      <div className="mt-2 flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {['Analiza mis gastos', 'Cómo ahorro más', 'Consejo deudas', 'Arriendo'].map(q => (
          <button key={q} onClick={() => setInput(q)} className="whitespace-nowrap text-[11px] font-medium px-3 py-1.5 rounded-full bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700">{q}</button>
        ))}
      </div>
    </div>
  );
}

function IncomeWorkModal({ onClose, appData, updateData, currentMonth, currentYear, daysInMonth, colorTheme, showToast }: any) {
  const [tab, setTab] = useState<'monthly' | 'daily'>(appData.income.type);
  const [monthly, setMonthly] = useState(appData.income.monthly.toString());
  const [daily, setDaily] = useState(appData.income.daily.toString());

  const workDays = appData.workDays.filter((wd: any) => {
    const { y, m } = parseDateStr(wd.date);
    return y === currentYear && m === currentMonth + 1;
  });

  const toggleDay = (dateStr: string) => {
    updateData('workDays', (prev: any[]) => {
      const existing = prev.find((d: any) => d.date === dateStr);
      if (existing) {
        return prev.map((d: any) => d.date === dateStr ? { ...d, worked: !d.worked } : d);
      } else {
        return [...prev, { date: dateStr, worked: true }];
      }
    });
  };

  const save = () => {
    updateData('income', { type: tab, monthly: Number(monthly) || 0, daily: Number(daily) || 0 });
    showToast('Ingresos actualizados');
    onClose();
  };

  const workedCount = workDays.filter((d: any) => d.worked).length;
  const dailyTotal = workedCount * (Number(daily) || 0);

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-t-[28px] sm:rounded-[28px] p-5 shadow-2xl animate-[slideUp_0.25s_ease] max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-[16px] flex items-center gap-2"><Briefcase size={18} /> Configurar ingresos</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center"><X size={14} /></button>
        </div>

        <div className="flex gap-2 p-1 bg-zinc-100 dark:bg-zinc-800 rounded-full mb-4">
          <button onClick={() => setTab('monthly')} className={`flex-1 h-9 rounded-full text-[13px] font-bold transition ${tab === 'monthly' ? 'bg-zinc-900 dark:bg-white text-white dark:text-black shadow' : 'text-zinc-500'}`}>Mensual fijo</button>
          <button onClick={() => setTab('daily')} className={`flex-1 h-9 rounded-full text-[13px] font-bold transition ${tab === 'daily' ? 'bg-zinc-900 dark:bg-white text-white dark:text-black shadow' : 'text-zinc-500'}`}>Por días</button>
        </div>

        {tab === 'monthly' ? (
          <div className="space-y-3">
            <div><label className="text-[11px] font-bold text-zinc-500 uppercase tracking-widest">Salario mensual neto</label><input type="number" value={monthly} onChange={e => setMonthly(e.target.value)} className="mt-1 w-full h-12 px-4 rounded-2xl bg-zinc-100 dark:bg-zinc-800 outline-none font-bold text-[15px]" placeholder="Ej: 2800000" /></div>
            <p className="text-[11px] text-zinc-500">Se usa como ingreso base para todos los cálculos 50/30/20.</p>
          </div>
        ) : (
          <div className="space-y-3">
            <div><label className="text-[11px] font-bold text-zinc-500 uppercase tracking-widest">Pago por día</label><input type="number" value={daily} onChange={e => setDaily(e.target.value)} className="mt-1 w-full h-12 px-4 rounded-2xl bg-zinc-100 dark:bg-zinc-800 outline-none font-bold text-[15px]" placeholder="Ej: 90000" /></div>
            <div className="bg-zinc-50 dark:bg-zinc-800/60 rounded-2xl p-3 border border-zinc-100 dark:border-zinc-800">
              <div className="flex justify-between text-[12px] font-bold mb-2"><span>Días trabajados</span><span className={colorTheme.bg + ' ' + colorTheme.text + ' px-2 py-0.5 rounded-full text-[11px]'}>{workedCount} días = {formatCurrency(dailyTotal)}</span></div>
              <div className="grid grid-cols-7 gap-1.5">
                {Array.from({ length: daysInMonth }, (_, i) => {
                  const day = i + 1;
                  const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                  const wd = workDays.find((w: any) => w.date === dateStr);
                  const worked = wd?.worked;
                  return (
                    <button key={day} onClick={() => toggleDay(dateStr)} className={`h-9 rounded-xl text-[12px] font-bold border transition ${worked ? `${colorTheme.bg} ${colorTheme.text} border-transparent` : 'bg-white dark:bg-zinc-900 border-zinc-100 dark:border-zinc-800 hover:border-zinc-300'}`}>{day}</button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        <button onClick={save} className={`mt-5 w-full h-12 rounded-2xl font-bold ${colorTheme.bg} ${colorTheme.text}`}>Guardar</button>
      </div>
    </div>
  );
}

function SettingsModal({ onClose, onLogout, user, appData, appColor, setAppColor, theme, toggleTheme, colorTheme, showToast, setAppData }: any) {
  const exportData = () => {
    const blob = new Blob([JSON.stringify(appData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `mis-finanzas-${user.username}-${toISODate(new Date())}.json`; a.click();
    URL.revokeObjectURL(url);
    showToast('Datos exportados');
  };

  const clearData = () => {
    if (!confirm('¿Borrar TODOS los datos de ' + user.username + '? No se puede deshacer.')) return;
    localStorage.removeItem(`misfinanzas_v8_${user.username}`);
    setAppData({
      income: { type: 'monthly', monthly: 0, daily: 0 },
      expenses: [], rent: { total: 0, dueDay: 1, payments: [] },
      goals: [], workDays: [], subscriptions: [], budgets: { comida: 0, transporte: 0, ocio: 0, salud: 0, otros: 0 }, debts: []
    });
    showToast('Datos borrados');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-t-[28px] sm:rounded-[28px] p-5 shadow-2xl animate-[slideUp_0.25s_ease] max-h-[90vh] overflow-y-auto no-scrollbar">
        <div className="flex justify-between items-center mb-5">
          <h3 className="font-bold text-[16px]">Configuración</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center"><X size={14} /></button>
        </div>

        <div className="space-y-5">
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-100 dark:border-zinc-800">
            <div className={`w-10 h-10 rounded-full ${colorTheme.bg} ${colorTheme.text} flex items-center justify-center font-bold`}>{user.username[0].toUpperCase()}</div>
            <div><p className="text-[13px] font-bold">{user.username}</p><p className="text-[11px] text-zinc-500">Local • {user.isGuest ? 'Invitado' : 'Cuenta local'}</p></div>
            <div className="ml-auto"><span className="text-[10px] font-bold px-2 py-1 rounded-full bg-emerald-100 text-emerald-700">Encriptado local</span></div>
          </div>

          <div>
            <p className="text-[11px] font-bold uppercase tracking-widest text-zinc-500 mb-2">Color de la app</p>
            <div className="flex gap-2.5">
              {Object.entries(APP_COLORS).map(([key, col]: any) => (
                <button key={key} onClick={() => { setAppColor(key); showToast(`Tema ${col.name}`); }} className={`w-10 h-10 rounded-full ${col.preview} ring-2 ring-offset-2 dark:ring-offset-zinc-900 transition ${appColor === key ? col.ring : 'ring-transparent'}`} />
              ))}
            </div>
          </div>

          <div>
            <p className="text-[11px] font-bold uppercase tracking-widest text-zinc-500 mb-2">Apariencia</p>
            <button onClick={toggleTheme} className="w-full h-12 rounded-2xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-between px-4">
              <span className="text-[13px] font-semibold flex items-center gap-2">{theme === 'light' ? <Sun size={16} /> : <Moon size={16} />} Tema {theme === 'light' ? 'Claro' : 'Oscuro'}</span>
              <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-white dark:bg-zinc-700 shadow-sm">{theme === 'light' ? '☀️' : '🌙'}</span>
            </button>
          </div>

          <div>
            <p className="text-[11px] font-bold uppercase tracking-widest text-zinc-500 mb-2">Datos</p>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={exportData} className="h-12 rounded-2xl bg-zinc-900 dark:bg-white text-white dark:text-black text-[13px] font-bold flex items-center justify-center gap-2"><Download size={14} /> Exportar JSON</button>
              <button onClick={clearData} className="h-12 rounded-2xl bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-300 border border-rose-100 dark:border-rose-900/30 text-[13px] font-bold flex items-center justify-center gap-2"><AlertTriangle size={14} /> Borrar datos</button>
            </div>
            <p className="text-[10px] text-zinc-500 mt-2">Los datos se guardan solo en este dispositivo (localStorage). Clave: misfinanzas_v8_{user.username}</p>
          </div>

          <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800">
            <button onClick={() => { onLogout(); onClose(); }} className="w-full h-12 rounded-2xl bg-zinc-100 dark:bg-zinc-800 text-[13px] font-bold flex items-center justify-center gap-2 hover:bg-zinc-200 dark:hover:bg-zinc-700"><LogOut size={14} /> Cerrar sesión</button>
            <p className="text-center text-[10px] text-zinc-400 mt-3">Mis Finanzas Pro • Hecho en Colombia 🇨🇴 • v8.1 • Solo frontend</p>
          </div>
        </div>
      </div>
    </div>
  );
}
