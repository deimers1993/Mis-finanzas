# Mis Finanzas Pro - APK via GitHub Actions

Instrucciones en el chat.